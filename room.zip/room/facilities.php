<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>theunist hostel-FACILITIES</title>
    
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
<?php require('inc/links.php')?>
<style>
  .pop:hover{
    border-top-color: var(--teal_hover) !important;
    transform:scale(1.03);
    transition:all 0.3s;
  }
</style>

</head>
<body class="bg-light">

   <?php require('inc/header.php')?>
  
  <div class="my-5 px-4">
    <h2 class=" fw-bold h-font text-center " >OUR FACILITIES</h2>
    <div class="h-line bg-dark"></div>
    <p class="text-center mt-3">
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maxime velit nam <br> repudiandae odio delectus cum ullam iusto consequuntur, perspiciatis explicabo illo autem unde saepe rem!
    </p>
   </div> 

   <div class="container">
     <div class="row ">
      
       <div  class="col-lg-4 col-md-6 mb-5 px-4">
         <div  class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
          <a href="room1.php" class="text-black text-decoration-none ">
           <div class="d-flex align-items-center mb-2">
           <img src="image/facilities/wifi.png" width="40px">
           <h5 class="m-0 ms-3"><a href="room1.php" class="text-black text-decoration-none">wifi</a> </h5>
           </div>
           <p class="color-black"><a href="room1.php" class="text-black text-decoration-none">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat repellendus quibusdam nostrum expedita consequuntur doloribus ut!</a></p>
          </a>
         </div> 
       </div>
      

       <div class="col-lg-4 col-md-6 mb-5 px-4">
        <a href="room1.php" class="text-black text-decoration-none">
         <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
           <div class="d-flex align-items-center mb-2">
           <img src="image/facilities/wifi.png" width="40px">
           <h5 class="m-0 ms-3">wifi</h5>
           </div>
           <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat repellendus quibusdam nostrum expedita consequuntur doloribus ut!</p>
         </div> 
        </a>
       </div>
       <div class="col-lg-4 col-md-6 mb-5 px-4">
         <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
           <div class="d-flex align-items-center mb-2">
           <img src="image/facilities/wifi.png" width="40px">
           <h5 class="m-0 ms-3">wifi</h5>
           </div>
           <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat repellendus quibusdam nostrum expedita consequuntur doloribus ut!</p>
         </div> 
       </div>
       <div class="col-lg-4 col-md-6 mb-5 px-4">
         <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
           <div class="d-flex align-items-center mb-2">
           <img src="image/facilities/wifi.png" width="40px">
           <h5 class="m-0 ms-3">wifi</h5>
           </div>
           <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat repellendus quibusdam nostrum expedita consequuntur doloribus ut!</p>
         </div> 
       </div>
       <div class="col-lg-4 col-md-6 mb-5 px-4">
         <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
           <div class="d-flex align-items-center mb-2">
           <img src="image/facilities/wifi.png" width="40px">
           <h5 class="m-0 ms-3">wifi</h5>
           </div>
           <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat repellendus quibusdam nostrum expedita consequuntur doloribus ut!</p>
         </div> 
       </div>
       <div class="col-lg-4 col-md-6 mb-5 px-4">
         <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
           <div class="d-flex align-items-center mb-2">
           <img src="image/facilities/wifi.png" width="40px">
           <h5 class="m-0 ms-3">wifi</h5>
           </div>
           <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat repellendus quibusdam nostrum expedita consequuntur doloribus ut!</p>
         </div> 
       </div>
     </div>
   </div>


     
  <?php require('inc/footer.php')?>
  
  
  

  <h6 class="text-center bg-dark text-white p-3 m-0">Designed and Develop by Shoeb</h6>
       
   
</body>
</html>