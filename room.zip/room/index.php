<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>theunist hostel-HOME</title>
    
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
  <?php require('inc/links.php')?>
<style>
     *{
       margin: 0;
       padding:0;
     }
     .availability-form{
     margin-top: -50px;
     z-index:2;
     position: relative;
   }

   @media screen and (max-width:575px){
    .availability-form{
     margin-top: 25px;
     padding: 0 35px;
    }
   }
</style>
</head>
<body class="bg-light">

   <?php require('inc/header.php')?>


   <!-- Carousel -->
  <div class="container-fluid px-lg-4 mt-4 ">
   <div class="swiper swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <img src="image/carousel/a.jpg" class="w-100 d-block" />
        </div>
        <div class="swiper-slide">
          <img src="image/carousel/b.jpg" class="w-100 d-block"  />
        </div>
        <div class="swiper-slide">
          <img src="image/carousel/c.jpg" class="w-100 d-block" />
        </div>
        <div class="swiper-slide">
          <img src="image/carousel/d.jpg" class="w-100 d-block"  />
        </div>
      </div>
    </div>

  </div>
   
  <div class="h-line bg-dark "></div>
    <p class="text-center mt-5 p-5 font-weight-bold">
      Campus has a fully air-conditioned hostel with a capacity of 200 beds that is equipped with latest firefighting system, 24 x7 power backup, Security, hot water facility and water coolers fitted with ROs. There is a facility of Doctor on Call in addition to the medical room which is open during all working hours of the institute. There is a common utility area that has refrigerators, microwaves, induction heaters, steam irons and electric kettles for the use of students.  The students have a facility for getting the laundry done for an outsource service and each balcony has drying stands for clothes. Each hostel room is provided a bed, inbuilt cupboard, a study table and a chair.  For recreation, the hostel has TVs and indoor games.  The hostel is equipped with elevator and toilets for special needs students.
    </p>

  <!-- Check availability form START -->

  <!-- <div class="container availability-form">
    <div class="row">
      <div class="col-lg-12 bg-white shadow p-4 rounded">
        <h5 class="mb-4">Check Booking Availability</h5>
        <form>
          <div class="row align-items-end">
            <div class="col-lg-3 mb-3">
              <label class="form-label" style=" font-weight: 500;">Check-in</label>
              <input type="date" class="form-control shadow-none">
            </div>
            <div class="col-lg-3  mb-3">
              <label class="form-label" style=" font-weight: 500;">Check-out</label>
              <input type="date" class="form-control shadow-none">
            </div>
            <div class="col-lg-3  mb-3">
             <label class="form-label" style=" font-weight: 500;">Adult</label>
              <select class="form-select shadow-none">
                  <option selected>Open this select menu</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
              </select> 
            </div>
            <div class="col-lg-2  mb-3">
             <label class="form-label" style=" font-weight: 500;">children</label>
              <select class="form-select shadow-none">
                  <option selected>Open this select menu</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
              </select> 
            </div>
            <div class="col-lg-1 mb-lg-3 mt-2">
              <button type="submit" class="btn text-white shadow-none custom-bg">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div> -->

  <!-- Check availability form END -->

 <!-- Our Rooms START -->
  
  <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">OUR ROOMS</h2>

  <div class="container">
    <div class="row">
      <!-- //ROOM 1 START -->
      <div class="col-lg-4 col-md-6 my-3">
        <div class="card border-0 shadow" style="max-width: 350px; margin: auto;">
         <img src="image/room/a.jpg" class="card-img-top">
         <div class="card-body">
           <h5 >Sample room name</h5>
           <h6 class="mb-4/">2000$ per month </h6>
           <div class="features mb-4">
             <h6 class="mb-2">Features</h6>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 1 rooms
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 1 bathroom
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 bed
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 study table
               </span>
           </div>
           <div class="facilities mb-4">
             <h6 class="mb-2">facilities</h6>
             <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 wifi
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 AC
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 room heater
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 time mesh
               </span>
           </div>
           <div class="rating mb-4">
                <h6 class="mb-2">Rating</h6>
                <span class="badge rounded-pill bg-light">
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-half text-warning"></i>
               </span>
           </div>
           <div class="d-flex justify-content-evenly mb-2">
              <a href="#" class="btn btn-sm text-white custom-bg shadow-none">Book Now</a>
              <a href="room1.php" class="btn btn-sm btn-outline-dark shadow-none">More details</a>
           </div>
          </div>
       </div>
     </div>
      <!-- //ROOM 1 START -->
       <!-- //ROOM 2 START -->
     <div class="col-lg-4 col-md-6 my-3">
        <div class="card border-0 shadow" style="max-width: 350px; margin: auto;">
         <img src="image/room/b.jpg" class="card-img-top">
         <div class="card-body">
           <h5 >Sample room name</h5>
           <h6 class="mb-4/">2000$ per month </h6>
           <div class="features mb-4">
             <h6 class="mb-2">Features</h6>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 1 rooms
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 1 bathroom
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 bed
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 study table
               </span>
           </div>
           <div class="facilities mb-4">
             <h6 class="mb-2">facilities</h6>
             <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 wifi
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 AC
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 room heater
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 time mesh
               </span>
           </div>
           <div class="rating mb-4">
                <h6 class="mb-2">Rating</h6>
                <span class="badge rounded-pill bg-light">
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-half text-warning"></i>
               </span>
           </div>
           <div class="d-flex justify-content-evenly mb-2">
              <a href="#" class="btn btn-sm text-white custom-bg shadow-none">Book Now</a>
              <a href="room2.php" class="btn btn-sm btn-outline-dark shadow-none">More details</a>
           </div>
          </div>
       </div>
     </div>
      <!-- //ROOM 2 START -->
       <!-- //ROOM 3 START -->
     <div class="col-lg-4 col-md-6 my-3">
        <div class="card border-0 shadow" style="max-width: 350px; margin: auto;">
         <img src="image/room/c.jpg" class="card-img-top">
         <div class="card-body">
           <h5 >Sample room name</h5>
           <h6 class="mb-4/">2000$ per month </h6>
           <div class="features mb-4">
             <h6 class="mb-2">Features</h6>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 1 rooms
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 1 bathroom
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 bed
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 study table
               </span>
           </div>
           <div class="facilities mb-4">
             <h6 class="mb-2">facilities</h6>
             <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 wifi
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 AC
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 room heater
               </span>
               <span class="badge rounded-pill bg-light text-dark text-wrap ">
                 2 time mesh
               </span>
           </div>
           <div class="rating mb-4">
                <h6 class="mb-2">Rating</h6>
                <span class="badge rounded-pill bg-light">
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-fill text-warning"></i>
                  <i class="bi bi-star-half text-warning"></i>
               </span>
           </div>
           <div class="d-flex justify-content-evenly mb-2">
              <a href="#" class="btn btn-sm text-white custom-bg shadow-none">Book Now</a>
              <a href="room3.php" class="btn btn-sm btn-outline-dark shadow-none">More details</a>
           </div>
          </div>
       </div>
     </div>
      <!-- //ROOM 3 START -->
       <div class="col-lg-12 text-center mt-5">
          <a href="rooms.php" class=" btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More rooms >>></a>
       </div>
    </div>
  </div>
  <!-- Our Rooms END-->

  <!-- OUR FACILITIES START-->
  <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">OUR FACILITIES</h2>
 
  <div class="container">
    <div class="row justify-content-evenly px-lg-0 px-md-0 px-5">
      <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
        <img src="image/facilities/wifi.png" width="80px">
        <h5 class="mt-3">Wifi</h5>
      </div>
      <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
        <img src="image/facilities/bed.png" width="80px">
        <h5 class="mt-3">bed</h5>
      </div>
      <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
        <img src="image/facilities/games.png" width="80px">
        <h5 class="mt-3">Games</h5>
      </div>
      <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
        <img src="image/facilities/sport.png" width="80px">
        <h5 class="mt-3">Sports</h5>
      </div>
      <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
        <img src="image/facilities/gym.png" width="80px">
        <h5 class="mt-3">Gym</h5>
      </div>
      <div class="col-lg-12 text-center mt-5">
        <div class="col-lg-12 text-center mt-5">
          <a href="facilities.php" class=" btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">MORE FACILITIES >>></a>
       </div>
      </div>
    </div>
  </div>
  <!-- OUR FACILITIES END-->

  <!-- OUR TESTMONIALS START-->
  <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font">REVIEW</h2>
   
  <div class="container mt-5">
    <div class="swiper Swiper-testmonials">
      <div class="swiper-wrapper mb-5">

        <div class="swiper-slide bg-white p-4">
          <div class="profile d-flex align-items-center p-4">
            <img src="image/facilities/a.jpeg" width="30px" >
            <h6 class="m-0 ms-2">Random user1</h6>
          </div>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Autem ab officiis doloribus dolore ipsam nobis aliquid rerum, dolor, suscipit ipsum animi omnis illum nisi perspiciatis.</p>
          <div class="rating">
            <span class="badge rounded-pill bg-light">
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-half text-warning"></i>
           </span>
          </div>
        </div>
        <div class="swiper-slide bg-white p-4">
          <div class="profile d-flex align-items-center p-4">
            <img src="image/facilities/sv.jpeg" width="30px" >
            <h6 class="m-0 ms-2">Random user1</h6>
          </div>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Autem ab officiis doloribus dolore ipsam nobis aliquid rerum, dolor, suscipit ipsum animi omnis illum nisi perspiciatis.</p>
          <div class="rating">
            <span class="badge rounded-pill bg-light">
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-half text-warning"></i>
           </span>
          </div>
        </div>
        <div class="swiper-slide bg-white p-4">
          <div class="profile d-flex align-items-center p-4">
            <img src="image/facilities/wifi.png" width="30px" >
            <h6 class="m-0 ms-2">Random user2</h6>
          </div>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Autem ab officiis doloribus dolore ipsam nobis aliquid rerum, dolor, suscipit ipsum animi omnis illum nisi perspiciatis.</p>
          <div class="rating">
            <span class="badge rounded-pill bg-light">
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-fill text-warning"></i>
              <i class="bi bi-star-half text-warning"></i>
           </span>
          </div>
        </div>
         
      </div>
      <div class="swiper-pagination"></div>
    </div>
    <div class="col-lg-12 text-center mt-5">
        <div class="col-lg-12 text-center mt-5">
          <a href="#" class=" btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">MORE REVIEW >>></a>
       </div>
      </div>

  </div>
  <!-- OUR TESTMONIALS END-->

  <!-- REACH US START-->
  <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font"> REACH US</h2>

  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8 p-4 mb-lg-0 mb-3 bg-white rounded">
        <iframe class="w-100 rounded" height="320" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d238130.11877536518!2d78.93242410447118!3d21.161028197938382!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd4c0a5a31faf13%3A0x19b37d06d0bb3e2b!2sNagpur%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1646937476421!5m2!1sen!2sin"     loading="lazy"></iframe>
      </div>
      <div class="col-lg-4 col-md-4">
         <div class="bg-white p-4 rounded mb-4">
           <h5>Call us</h5>
           <a href="tel:+91 8390047993" class="d-inline-block mb-2 text-decoration-none text-dark"><i class="bi bi-telephone-fill"></i>+91 8390047993</a>
           <br>
           <a href="tel:+91 8390047993" class="d-inline-block  text-decoration-none text-dark"><i class="bi bi-telephone-fill"></i>+91 8390047993</a>
         </div>
         <div class="bg-white p-4 rounded mb-4">
          <h5>follow us</h5>
          <a href="#" class="d-inline-block mb-3 ">
            <span class="badge bg-light text-dark fs-6 p-2"><i class="bi bi-twitter me-1"></i>Twitter</span>
          </a>
          <br>
          <a href="#" class="d-inline-block mb-3 ">
            <span class="badge bg-light text-dark fs-6 p-2"><i class="bi bi-twitter me-1 "></i>Twitter</span>
          </a>
          <br>
          <a href="#" class="d-inline-block mb-3 ">
            <span class="badge bg-light text-dark fs-6 p-2"><i class="bi bi-twitter me-1"></i>Twitter</span>
          </a>
          <br>
        </div>
      </div>
    </div>
  </div>
  <!-- REACH US END-->
   
  <?php require('inc/footer.php')?>
  
  
  

  <h6 class="text-center bg-dark text-white p-3 m-0">Designed and Develop by Shoeb</h6>
       
    <script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

    <script>
      var swiper = new Swiper(".swiper-container", {
        spaceBetween: 30,
        effect: "fade",
        loop: true,
        autoplay: {
          delay:2500,
          disableOnInteraction: false,
        }
      });
      var swiper = new Swiper(".Swiper-testmonials", {
        effect: "coverflow",
        grabCursor: true,
        centeredSlides: true,
        slidesPerView: "auto",
        slidesPerView: "3",
        loop: true,
        coverflowEffect: {
          rotate: 50,
          stretch: 0,
          depth: 100,
          modifier: 1,
          slideShadows: true,
        },
        pagination: {
          el: ".swiper-pagination",
        },
        breakpoints:{
          320 :{
            slidesPerView:1 ,
          } ,
          640 :{
            slidesPerView:1 ,
          } ,
          768 :{
            slidesPerView:2 ,
          } ,
          1024 :{
            slidesPerView:3 ,
          } ,
        }
      });
    </script>
</body>
</html>