   <div class="container-fluid bg-white mt-5 ">
     <div class="row">
       <div class="col-lg-3">
         <h3 class="h-font fw-bold fs-3 mb-2">Unist Hostel</h3>
         <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dignissimos, aperiam officia? Voluptatem ducimus sed dignissimos hic ad dolorum esse corrupti, maiores repudiandae sequi. Commodi exercitationem repudiandae neque modi? Fugiat quae enim vel est.</p>
       </div>
       <div class="col-lg-3">
         <h5 class="mb-3 text-algin-center">Links</h5>
         <a href="index.php" class="d-inline-block mb-2 text-dark text-decoration-none">Home</a><br>
         <a href="rooms.php" class="d-inline-block mb-2 text-dark text-decoration-none">Rooms</a><br>
         <a href="facilities.php" class="d-inline-block mb-2 text-dark text-decoration-none">Facilities</a><br>
         <a href="contact.php" class="d-inline-block mb-2 text-dark text-decoration-none">Contact us </a><br>
         <a href="about.php" class="d-inline-block mb-2 text-dark text-decoration-none">About</a><br>
      </div>
      <div class="col-lg-3">
         <h5 class="mb-3">Follows us</h5>
         <a href="#" class="d-inline-block text-dark text-decoration-none mb-2 ">
          <i class="bi bi-twitter me-1"></i>Twitter
        </a><br>
        <a href="#" class="d-inline-block text-dark text-decoration-none mb-2 ">
          <i class="bi bi-twitter me-1"></i>Twitter
        </a><br>
        <a href="#" class="d-inline-block text-dark text-decoration-none mb-2 ">
          <i class="bi bi-twitter me-1"></i>Twitter
        </a><br>
      </div>
      <div class="col-lg-3">
         <h5 class="mb-3">Follows us</h5>
         <a href="#" class="d-inline-block text-dark text-decoration-none mb-2 ">
          <i class="bi bi-twitter me-1"></i>Twitter
        </a><br>
        <a href="#" class="d-inline-block text-dark text-decoration-none mb-2 ">
          <i class="bi bi-twitter me-1"></i>Twitter
        </a><br>
        <a href="#" class="d-inline-block text-dark text-decoration-none mb-2 ">
          <i class="bi bi-twitter me-1"></i>Twitter
        </a><br>
      </div>
      
     </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>