 <nav class="navbar navbar-expand-lg navbar-light bg-white px-lg-3 py-lg-2 shadow-sm sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand me-5 fw-bold fs-3 h-font" href="index.php">The Unist Hostel</a>
    <button class="navbar-toggler shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active me-2" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-2" href="rooms.php">rooms</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-2" href="facilities.php">Facilities</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-2" href="contact.php">Contact us </a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="about.php">About</a>
        </li>
      </ul>
      <!-- Button trigger modal -->
      <div class="d-flex">
        <button type="button" class="btn btn-outline-dark shadow-none me-lg-3 me-3" data-bs-toggle="modal" data-bs-target="#loginmodal">
        Login
        </button>
        <button type="button" class="btn btn-outline-dark shadow-none " data-bs-toggle="modal" data-bs-target="#registermodal">
        Register
        </button>
      </div>
    </div>
  </div>
 </nav>
    
  <!-- LOGIN FORM START -->  
 <div class="modal fade" id="loginmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <form >
            
        
      <div class="modal-header">
        <h5 class="modal-title d-flex align-items-center"><i class="bi bi-people fs-3 me-2"></i>Usser Login</h5>
        <button type="reset" class="btn-close showdow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Email address</label>
        <input type="email" class="form-control shadow-none" >
      </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Password</label>
    <input type="password" class="form-control shadow-none" >
  </div>
  <div class="d-flex algin-item-center justify-content-between mb-2">
      <button type="submit" class="btn btn-dark shadow-none">LOgin</button>
      <a href="javascript: void(0)" class="text-secondary text decoration-none">forgot password</a>
  </div>
      </div>
      
      </form>
    </div>
  </div>
 </div>
 <!-- LOGIN FORM END -->  

<!-- REGISTER FORM START -->  
  <div class="modal fade" id="registermodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg">
    <div class="modal-content">
     <form >
            
        
        <div class="modal-header">
          <h5 class="modal-title d-flex align-items-center"><i class="bi bi-person-lines-fill fs-3 me-3"></i> Usser Registeration</h5>
          <button type="reset" class="btn-close showdow-none" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <span class="badge rounded-pill bg-light text-dark mb-3 text-wrap lh-base">
            Note: Your details must match with your ID(Aadhar card, passport,driving licences,etc.)
            That will be rquired during check-in.
           </span>

         <div class="container-fluid">
           <div class="row">   <!-- ragister form -->
              <div class="col-md-6 ps-0 mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name</label>
                     <input type="text" class="form-control shadow-none" >
               </div>
              <div class="col-md-6 p-0 mb-3">
                   <label for="exampleInputEmail1" class="form-label">Email</label>
                   <input type="email" class="form-control shadow-none" >
               </div>
              <div class="col-md-6 ps-0 mb-3">
                   <label for="exampleInputEmail1" class="form-label">Phone Number</label>
                   <input type="number" class="form-control shadow-none" >
               </div>
              <div class="col-md-6 p-0 mb-3">
                    <label for="exampleInputEmail1" class="form-label">picture</label>
                    <input type="file" class="form-control shadow-none" >
               </div>
              <div class="col-md-12 p-0 mb-3">
                    <label for="exampleInputEmail1" class="form-label">address</label>
                    <textarea class="form-control shadow-none"  rows="1"></textarea>
               </div>
              <div class="col-md-6 ps-0 mb-3">
                    <label for="exampleInputEmail1" class="form-label">pincode</label>
                    <input type="number" class="form-control shadow-none" >
               </div>
              <div class="col-md-6 p-0 mb-3">
                    <label for="exampleInputEmail1" class="form-label">date of birth</label>
                    <input type="date" class="form-control shadow-none" >
               </div>
              <div class="col-md-6 ps-0 mb-3">
                    <label for="exampleInputEmail1" class="form-label">Password</label>
                    <input type="password" class="form-control shadow-none" >
               </div>
              <div class="col-md-6 p-0 mb-3">
                    <label for="exampleInputEmail1" class="form-label">Conform Password</label>
                    <input type="passwod" class="form-control shadow-none" >
               </div>
            </div>
                <div class="text-center my-1">
                      <button type="submit" class="btn btn-dark shadow-none">REGISTER</button>
                </div>
          </div>
        </div>
      </form>
    </div>
   </div>
  </div>
<!-- REGISTER FORM END -->  