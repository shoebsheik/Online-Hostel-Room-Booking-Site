<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>theunist hostel-ROOMS</title>
    
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
<?php require('inc/links.php')?>
<style>
  .pop:hover{
    border-top-color: var(--teal_hover) !important;
    transform:scale(1.03);
    transition:all 0.3s;
  }
  
</style>

</head>
<body class="bg-light">

   <?php require('inc/header.php')?>
  
  <div class="my-5 px-4">
    <h2 class=" fw-bold h-font text-center " > OUR ROOM</h2>
    <div class="h-line bg-dark"></div>
    <!-- <p class="text-center mt-3">
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maxime velit nam <br> repudiandae odio delectus cum ullam iusto consequuntur, perspiciatis explicabo illo autem unde saepe rem!
    </p> -->
   </div> 
           <!-- ROOM COROSEL START -->
           <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="image/room/a1.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="image/room/b1.JPG" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="image/room/c1.jpg" class="d-block w-100" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
           </div>    
           <!-- ROOM COROSEL END -->
 <br><br><br>
          <!-- DESCRPTION START -->
       <div class="container">
          <div class="row ">
               <div class="col-lg-5 col-md-6 mb-5 px-4">
                  <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                    <h5 class="mb-4">Room Instructions</h5>
              <div class="features mb-3">
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  Features</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  Main Entrance System - Register , Biometric</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i> Professional security guards</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  CCTV surveillance</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  Fire Safety Provision</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  Warden stay in the hostel 24*7</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  checks for drug and alcohol abuse</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  In-time - 8:00 pm</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  and booking policies  vary according to
                  hostels type. Check what Conditions might apply to
                  each option when making your selection.</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  Electricity bill not included in Rent</h6>
                <h6 class="mb-2"><i class="bi bi-check-circle-fill"></i>  Parental Stay option - Depends on availability</h6>
              </div>
              <!-- <ul class="h-rules-list">
                 <i class="bi bi-check-circle-fill" aria-hidden="true"></i>  <strong>Main Entrance System - Register , Biometric</strong> 
                <li><strong>Professional security guards</strong> </li>
                <li><strong> CCTV surveillance</strong></li>
                <li><strong>Fire Safety Provision</strong> </li>
                <li><strong> Warden stay in the hostel 24*7</strong></li>
                <li><strong>checks for drug and alcohol abuse</strong> </li>
                <li><strong> In-time - 8:00 pm</strong></li>
                <li><strong> and booking policies vary according to
                     hostels type. Check what Conditions might apply to
                     each option when making your selection.</strong>
                </li>
                 <li><strong>Electricity bill not included in Rent</strong></li>
                <li><strong>Parental Stay option - Depends on availability</strong></li>
              </ul> -->
              <!-- <div class="facilities mb-4">
                <h6 class="mb-2">facilities</h6>
              </div> -->
                  </div> 
               </div> 
               <div class="col-md-5 px-lg-3 px-md-3 px-0">
                <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                <h5 class="mb-3"> Room 101</h5>
                <div class="features mb-3">
                  <h6 class="mb-2">Features</h6>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      Lockers 
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      Wardrobe 
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                       bed
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                       study table
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      fridge
                   </span>
                </div>
                <div class="facilities mb-4">
                  <h6 class="mb-2">facilities</h6>
                  <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      wifi
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      AC
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      room heater
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      2 time mesh
                    </span>
                </div>
                <div class="Amenities mb-4">
                  <h6 class="mb-2">Other Amenities</h6>
                  <span class="badge rounded-pill bg-light text-dark text-wrap ">
                    Sports accessories
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      Gym
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      Games - Tennis , Table Tennis , Pool/Snooker , Chess , Carrom 
                    </span>
                    <span class="badge rounded-pill bg-light text-dark text-wrap ">
                      Garden
                    </span>
                </div>
                <h6 class="mb-4/">200$ per month </h6>
                <div class="rating mb-4">
                  <h6 class="mb-2">Rating</h6>
                  <span class="badge rounded-pill bg-light">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-half text-warning"></i>
                 </span>
                
                </div>
                </div>
              </div>
               <div class="col-md-2 text-center">
                <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                   <a href="#" class="btn btn-sm w-100 text-white custom-bg shadow-none mb-2">Book Now</a>
                </div> 
              </div>
          </div>
       </div>
       <!-- DESCRPTION END -->

  <?php require('inc/footer.php')?>
  
  <h6 class="text-center bg-dark text-white p-3 m-0">Designed and Develop by Sheikh Mohd.Shoeb</h6>
       
   
</body>
</html>
  